class Customer{
#user1 modified
#user2 modified
private int userId;
private String email;

private int customerId;
private String customerName;
private boolean status;
private String gender;


}