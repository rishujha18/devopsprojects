package com.hsbc.banking.day20springbootbankingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day20springbootbankingdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day20springbootbankingdemoApplication.class, args);
	}

}
