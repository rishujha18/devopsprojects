firstName="Parameswari"
lastName="Bala"
profile="Trainer"
console.log(firstName+","+lastName);
